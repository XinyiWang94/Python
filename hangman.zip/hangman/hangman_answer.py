# -*- coding: utf-8 -*-
"""
Created on Fri Sep 16 17:53:03 2016

@author: wangxinyi
"""

def isWordGuessed(secretWord, lettersGuessed):
    '''
    secretWord: string, the word the user is guessing
    lettersGuessed: list, what letters have been guessed so far
    returns: boolean, True if all the letters of secretWord are in lettersGuessed;
      False otherwise
    '''
    # FILL IN YOUR CODE HERE...
    t = 0
    for w in lettersGuessed:
        if w in secretWord:
            t += 1
    if t == len(secretWord):
        return True
    else:
        return False

def getGuessedWord(secretWord, lettersGuessed):
    '''
    secretWord: string, the word the user is guessing
    lettersGuessed: list, what letters have been guessed so far
    returns: string, comprised of letters and underscores that represents
      what letters in secretWord have been guessed so far.
    '''
    # FILL IN YOUR CODE HERE...
    word = ''
    for l in secretWord:
        if l in lettersGuessed:
            word += l
        else:
            word += '_'
    return word

def getAvailableLetters(lettersGuessed):
    '''
    lettersGuessed: list, what letters have been guessed so far
    returns: string, comprised of letters that represents what letters have not
      yet been guessed.
    '''
    # FILL IN YOUR CODE HERE...
    alpha = [chr(i) for i in range(97,123)]
    result = ''
    for l in alpha:
        if l not in lettersGuessed:
            result += l
    return result

def hangman(secretWord):
    print('Welcome to the game, Hangman!')
    print('I am thinking of a word that is ' + str(len(secretWord)) + ' letters long')
    print('-----------')
    num = 8
    i = 0
    lettersGuessed = []
    while num > 0:
        j = 0
        print('You have '+ str(num) + ' guesses left.')        
        print('Available letters: '+ getAvailableLetters(lettersGuessed))
        letter = input('Please guess a letter: ')
        if letter in lettersGuessed:
            j = 1 
            print("Oops! You've already guessed that letter:" + getGuessedWord(secretWord, lettersGuessed))
            print('Good guess: '+ getGuessedWord(secretWord, lettersGuessed))
        else:
            lettersGuessed.append(letter)
        if j == 0:  
            if letter in secretWord:
                j = 1
                print('Good guess: '+ getGuessedWord(secretWord, lettersGuessed))
            else:
                print('Oops! That letter is not in my word: '+ getGuessedWord(secretWord, lettersGuessed))
            print('-----------')
            if isWordGuessed(secretWord, lettersGuessed):
                print('Congratulations, you won!')
                i = 1
                break
            if j == 0:
                num -= 1
    if i!= 1:
        print('Sorry, you ran out of guesses. The word was else. ')
            
        
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    